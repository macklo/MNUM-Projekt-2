function [ x , y ] = dane( )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
x = [-5:5]';
y = [2.0081,-3.6689,-4.9164,-1.8700,-0.0454,0.5504,-0.8392,-1.0113,2.6133,14.6156,39.6554]';
end

